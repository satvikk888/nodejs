# FS-NODE-EXP-4
This repo belongs to University.

# FS Node Experiment Proofs

## Experiment 1
<img src="./Assests/Practice1/NodeFS11.png" alt="NodeFS11">
<img src="./Assests/Practice1/NodeFS13.png" alt="NodeFS13">
<img src="./Assests/Practice1/NodeFS12.png" alt="NodeFS12">
<img src="./Assests/Practice1/NodeFS14.png" alt="NodeFS14">

## Experiment 2
<img src="./Assests/Practice2/NodeFS21.png" alt="NodeFS21">
<img src="./Assests/Practice2/NodeFS22.png" alt="NodeFS22">
<img src="./Assests/Practice2/NodeFS22.png" alt="NodeFS22">
<img src="./Assests/Practice2/NodeFS22.png" alt="NodeFS22">

## Experiment 3
<img src="./Assests/Practice3/NodeFS31.png" alt="NodeFS31">
<img src="./Assests/Practice3/NodeFS32.png" alt="NodeFS32">
<img src="./Assests/Practice3/NodeFS33.png" alt="NodeFS33">
<img src="./Assests/Practice3/NodeFS34.png" alt="NodeFS34">